package com.julie.youtube;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.julie.youtube.adapter.RecyclerViewAdapter;
import com.julie.youtube.model.Benz;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RequestQueue requestQueue;
    ArrayList<Benz> benzArrayList = new ArrayList<>();
    String youtubeUrl = "https://www.googleapis.com/youtube/v3/search?part=snippet&key=AIzaSyBbnT0X-K9587Ti2okL9JzOax3uB7gP3LA&q=%EB%B2%A4%EC%B8%A0&&maxResults=20&order=date&type=video&type=video&q=벤츠";

    RecyclerView recyclerView;
    RecyclerViewAdapter recyclerViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        requestQueue = Volley.newRequestQueue(MainActivity.this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                youtubeUrl,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i("AAA", response.toString());
                            try {
                                JSONArray items = response.getJSONArray("items");
                                for(int i = 0; i < response.length(); i++){
                                   JSONObject jsonObject = items.getJSONObject(i);
                                   JSONObject id = jsonObject.getJSONObject("id");
                                   String videoId = id.getString("videoId");
                                   JSONObject snippet = jsonObject.getJSONObject("snippet");
                                   String title = snippet.getString("title");
                                   String decs = snippet.getString("description");
                                   JSONObject thumbnails = snippet.getJSONObject("thumbnails");
                                   JSONObject def = thumbnails.getJSONObject("default");
                                   String url = def.getString("url");
                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        requestQueue.add(jsonObjectRequest);

    }
}




