package com.julie.youtube.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.julie.youtube.R;
import com.julie.youtube.model.Benz;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{
    Context context;
    ArrayList<Benz> benzArrayList;

    public RecyclerViewAdapter(Context context, ArrayList<Benz> benzArrayList) {
        this.context = context;
        this.benzArrayList = benzArrayList;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.benz_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder holder, int position) {
        Benz benz = benzArrayList.get(position);
        String etag = benz.getEtag();
        String nextPageToken = benz.getNextPageToken();
        String regionCode = benz.getRegionCode();
        int pageInfo = benz.getPageInfo();
        int items = benz.getItems();

        holder.txtTitle.setText(items);
        // 1. 핵심부분 : 이미지의 주소를 글라이드에 셋팅해준다.
        GlideUrl glideUrl = new GlideUrl(thumbnailUrl,
                new LazyHeaders.Builder().addHeader("User-Agent", "Android").build());
        Glide.with(context).load(glideUrl).into( holder.imgThumb  );

    }

    @Override
    public int getItemCount() {
        return benzArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView txtTitle;
        public TextView txtContent;
        public ImageView imgThumb;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTitle = itemView.findViewById(R.id.txtTitle);
            txtContent = itemView.findViewById(R.id.txtContent);
            imgThumb = itemView.findViewById(R.id.imgThumb);
            imgThumb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        }

    }
}



